
package ru.pathfinder.service;

public class Categoryservice {
    
}
